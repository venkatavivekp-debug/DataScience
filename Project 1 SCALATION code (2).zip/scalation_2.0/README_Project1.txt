To run Linear Regression run the following commands:

sbt "runMain scalation.project_1.multipleRegressionTestAutoMPG"
sbt "runMain scalation.project_1.multipleRegressionTestSeoulBikes"
sbt "runMain scalation.project_1.multipleRegressionTestBostonHousing"
sbt "runMain scalation.project_1.multipleRegressionTestEnergyHeating"
sbt "runMain scalation.project_1.multipleRegressionTestEnergyCooling"


to run Ridge Regression run the following:

sbt "runMain scalation.project_1.ridgeRegressionTestAutoMPG"
sbt "runMain scalation.project_1.ridgeRegressionTestSeoulBikes"
sbt "runMain scalation.project_1.ridgeRegressionTestBostonHousing"
sbt "runMain scalation.project_1.ridgeRegressionTestEnergyHeating"
sbt "runMain scalation.project_1.ridgeRegressionTestEnergyCooling" 

