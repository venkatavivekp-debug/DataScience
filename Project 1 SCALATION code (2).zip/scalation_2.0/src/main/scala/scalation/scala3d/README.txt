
This package is under development and is exploring the use of JavaFx/ScalaFx
as a lightweight 3D solution versus say libGDX or LWJGL.

