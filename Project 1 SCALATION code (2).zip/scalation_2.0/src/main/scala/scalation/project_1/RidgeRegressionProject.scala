package scalation.project_1

import scalation.modeling.RidgeRegression
import scala.math.sqrt
import scala.runtime.ScalaRunTime.stringOf

import scalation.mathstat._

import scala.util.Random

@main def ridgeRegressionTestSeoulBikes(): Unit =
    analyzeDatasetRidge("data/bike_data.csv", 1, "Seoul Bike Sharing")


@main def ridgeRegressionTestAutoMPG(): Unit =
    analyzeDatasetRidge("data/auto_mpg.csv", 0, "Auto MPG")


@main def ridgeRegressionTestBostonHousing(): Unit =
    analyzeDatasetRidge("data/boston_housing.csv", -1, "Boston Housing")


@main def ridgeRegressionTestEnergyHeating(): Unit =
    analyzeDatasetRidge("data/energy_efficiency.csv", 8, "Energy Efficiency - Heating")


@main def ridgeRegressionTestEnergyCooling(): Unit =
    analyzeDatasetRidge("data/energy_efficiency.csv", 9, "Energy Efficiency - Cooling")


@main def ridgeRegressionTestAllDatasets(): Unit =
    println("\n=== Seoul Bike Sharing Ridge Regression Analysis ===")
    ridgeRegressionTestSeoulBikes()
    
    println("\n=== Auto MPG Ridge Regression Analysis ===")
    ridgeRegressionTestAutoMPG()
    
    println("\n=== Boston Housing Ridge Regression Analysis ===")
    ridgeRegressionTestBostonHousing()
    
    println("\n=== Energy Efficiency Heating Ridge Regression Analysis ===")
    ridgeRegressionTestEnergyHeating()
    
    println("\n=== Energy Efficiency Cooling Ridge Regression Analysis ===")
    ridgeRegressionTestEnergyCooling()

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** Generic function to analyze any dataset using Ridge Regression with all numeric features.
  * @param filePath the path to the CSV file
  * @param targetCol the column index of the target variable (-1 means last column)
  * @param datasetName name of the dataset for display purposes
  */
def analyzeDatasetRidge(filePath: String, targetCol: Int, datasetName: String): Unit =


    def readAndPreprocessCSVMultiple(filePath: String, targetCol: Int): (MatrixD, VectorD, Array[String], Double, VectorD) = {
        val source = scala.io.Source.fromFile(filePath)
        val lines = source.getLines().toList
        source.close()
        

        val header = lines.head.split(',').map(_.trim)
        val dataLines = lines.drop(1)
        
        
        def safeToDouble(s: String): Option[Double] = {
            val cleaned = s.trim.toLowerCase
            cleaned match
                case "true" => Some(1.0)
                case "false" => Some(0.0)
                case "?" | "" => None
                case _ => 
                    try Some(cleaned.toDouble)
                    catch case _: NumberFormatException => 
                        println(s"safe_toDouble: can't parse '$cleaned' to create a Double")
                        None
        }
        

        val numColumns = header.length
        val actualTargetCol = if targetCol == -1 then numColumns - 1 else targetCol
        
        val numericColumns = (0 until numColumns).filter { col =>
            col == actualTargetCol ||
            dataLines.forall { line =>
                val values = line.split(',').map(_.trim)
                if values.length > col then safeToDouble(values(col)).isDefined else false
            }
        }.toVector
        
        println(s"Detected numeric columns: $numericColumns")
        

        val numericFeatureNames = numericColumns.filter(_ != actualTargetCol).map(header(_)).toArray
        

        val cleanedData = dataLines.flatMap { line =>
            val values = line.split(',').map(_.trim)
            

            val numericValues = numericColumns.map { col =>
                if values.length > col then safeToDouble(values(col)) else None
            }
            

            if numericValues.forall(_.isDefined) then
                Some(numericValues.map(_.get).toArray)
            else
                None
        }

        if cleanedData.isEmpty then
            throw new RuntimeException(s"No valid data found in $filePath. Check data format.")
        
        val numInstances = cleanedData.length
        val numFeatureCols = numericColumns.length - 1
        

        val targetColInNumeric = numericColumns.indexOf(actualTargetCol)
        if targetColInNumeric == -1 then
            throw new RuntimeException(s"Target column $actualTargetCol is not numeric")
        
        val featureCols = numericColumns.filter(_ != actualTargetCol)
        
        val xMatrix = new MatrixD(numInstances, numFeatureCols)
        val yVector = new VectorD(numInstances)

        for i <- 0 until numInstances do
            for j <- featureCols.indices do
                xMatrix(i, j) = cleanedData(i)(numericColumns.indexOf(featureCols(j)))
            yVector(i) = cleanedData(i)(targetColInNumeric)
        

        val mu_x = xMatrix.mean
        val mu_y = yVector.mean
        val x_centered = xMatrix - mu_x
        val y_centered = yVector - mu_y
        
        (x_centered, y_centered, numericFeatureNames, mu_y, mu_x)
    }


    def splitData(x_data: MatrixD, y_data: VectorD, trainRatio: Double, seed: Int): (MatrixD, VectorD, MatrixD, VectorD) = {
        Random.setSeed(seed)
        val numInstances = x_data.dim
        val numFeatures = x_data.dim2
        val indices = Random.shuffle((0 until numInstances).toList)
        val splitIndex = (numInstances * trainRatio).toInt
        
        val trainIndices = indices.slice(0, splitIndex)
        val testIndices = indices.slice(splitIndex, numInstances)
        
        val x_train = new MatrixD(trainIndices.size, numFeatures)
        val y_train = new VectorD(trainIndices.size)
        val x_test = new MatrixD(testIndices.size, numFeatures)
        val y_test = new VectorD(testIndices.size)
        
        for i <- trainIndices.indices do
            val originalIndex = trainIndices(i)
            x_train(i) = x_data(originalIndex)
            y_train(i) = y_data(originalIndex)
        
        for i <- testIndices.indices do
            val originalIndex = testIndices(i)
            x_test(i) = x_data(originalIndex)
            y_test(i) = y_data(originalIndex)
        
        (x_train, y_train, x_test, y_test)
    }

    try {
        println(s"\nAnalyzing $datasetName dataset using Ridge Regression...")
        
        val (x_data, y_data, numericFeatureNames, mu_y, mu_x) = readAndPreprocessCSVMultiple(filePath, targetCol)
        println(s"Dataset loaded: ${x_data.dim} instances, ${x_data.dim2} features")

        val (x_train, y_train, x_test, y_test) = splitData(x_data, y_data, 0.8, 42)

        
        val allFeatureNames = Array("intercept") ++ numericFeatureNames
        

        val mod = new RidgeRegression(x_train, y_train, allFeatureNames)
        

        val (best_lambda, sse_cv) = mod.findLambda
        println(s"Optimal lambda: $best_lambda with SSE_CV: $sse_cv")

        val hp = RidgeRegression.hp
        hp.update("lambda", best_lambda)
        val mod_opt = new RidgeRegression(x_train, y_train, allFeatureNames, hp)
        mod_opt.train() 


        val (yp_train, qof_train) = mod_opt.test(x_train, y_train)
        val yp_train_adjusted = yp_train + mu_y
        val (yp_test, qof_test) = mod_opt.test(x_test, y_test)
        val yp_test_adjusted = yp_test + mu_y

        println("Training Performance:")
        println(s"Train RMSE: ${qof_train(6)}")
        println(s"Train R-squared: ${qof_train(0)}")
        println(s"Training Performance: {'Mean Squared Error': '${f"${qof_train(5)}%1.5f"}', 'R-Squared': '${f"${qof_train(0)}%1.5f"}', 'Root Mean Squared Error': '${f"${qof_train(6)}%1.5f"}'}")
        
        println("\nTesting Performance:")
        println(s"Test RMSE: ${qof_test(6)}")
        println(s"Test R-squared: ${qof_test(0)}")
        println(s"Testing Performance: {'Mean Squared Error': '${f"${qof_test(5)}%1.5f"}', 'R-Squared': '${f"${qof_test(0)}%1.5f"}', 'Root Mean Squared Error': '${f"${qof_test(6)}%1.5f"}'}")

        // Cross-validation
        val qof_cv = mod_opt.crossValidate()
        

        val cv_mse = qof_cv(5).mean 
        val cv_rsq = qof_cv(0).mean
        val cv_rmse = qof_cv(6).mean
        
        println(s"Cross-Validation Results: {'MSE': '${f"$cv_mse%1.5f"}', 'R²': '${f"$cv_rsq%1.5f"}', 'RMSE': '${f"$cv_rmse%1.5f"}'}")
        

        println("\nModel Coefficients:")
        println(mod_opt.summary())
        
    } catch {
        case _: java.io.FileNotFoundException =>
            println(s"Error: File not found - $filePath")
            println("Please ensure the CSV file exists in the data directory.")
        case e: Exception =>
            println(s"Error processing $datasetName dataset: ${e.getMessage}")
            e.printStackTrace()
    }
