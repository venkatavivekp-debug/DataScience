error id: file://<WORKSPACE>/src/main/scala/scalation/modeling/linearRegressionExample.scala:predict.
file://<WORKSPACE>/src/main/scala/scalation/modeling/linearRegressionExample.scala
empty definition using pc, found symbol in pc: predict.
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -scalation/mathstat/model/predict.
	 -scalation/mathstat/model/predict#
	 -scalation/mathstat/model/predict().
	 -model/predict.
	 -model/predict#
	 -model/predict().
	 -scala/Predef.model.predict.
	 -scala/Predef.model.predict#
	 -scala/Predef.model.predict().
offset: 679
uri: file://<WORKSPACE>/src/main/scala/scalation/modeling/linearRegressionExample.scala
text:
```scala
package scalation
package modeling

import scalation.mathstat._

@main def linearRegressionExample(): Unit =
    // === Your dataset (replace with real values) ===
    val x = MatrixD((5, 2),       // 5 samples, 2 cols (intercept + 1 feature)
        1.0, 1.0,
        1.0, 2.0,
        1.0, 3.0,
        1.0, 4.0,
        1.0, 5.0
    )

    val y = VectorD(2.0, 2.8, 3.6, 4.5, 5.1)

    // === Train model ===
    val model = new SimpleRegression(x, y)
    model.trainNtest()           // fit & report results

    // === Make predictions ===
    val xNew = MatrixD((3, 2),   // 3 new samples
        1.0, 6.0,
        1.0, 7.0,
        1.0, 8.0
    )
    val yPred = model.pre@@dict(x)

    println(s"Predictions: $yPred")

    // === Plot actual vs predicted ===
    new Plot(x.col(1), y, null, "Training Data (y vs x)")
    new Plot(xNew.col(1), yPred, null, "Predictions (yPred vs x)")

```


#### Short summary: 

empty definition using pc, found symbol in pc: predict.