file://<WORKSPACE>/src/main/scala/scalation/project_1/linearRegressionProject.scala
empty definition using pc, found symbol in pc: 
semanticdb not found
empty definition using fallback
non-local guesses:
	 -scalation/mathstat/main.
	 -scalation/mathstat/main#
	 -scalation/mathstat/main().
	 -scalation/modeling/main.
	 -scalation/modeling/main#
	 -scalation/modeling/main().
	 -main.
	 -main#
	 -main().
	 -scala/Predef.main.
	 -scala/Predef.main#
	 -scala/Predef.main().
offset: 310
uri: file://<WORKSPACE>/src/main/scala/scalation/project_1/linearRegressionProject.scala
text:
```scala
package scalation.project_1

import scala.math.sqrt
import scala.runtime.ScalaRunTime.stringOf

import scalation.mathstat._
import scalation.modeling._
import scala.util.Random


@main def multipleRegressionTestSeoulBikes(): Unit =
    analyzeDatasetMultiple("data/bike_data.csv", 1, "Seoul Bike Sharing")

/
@@@main def multipleRegressionTestAutoMPG(): Unit =
    analyzeDatasetMultiple("data/auto_mpg.csv", 0, "Auto MPG")

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `multipleRegressionTestBostonHousing` main function to analyze the Boston Housing
  * dataset using Multiple Linear Regression with all features.
  * > runMain scalation.modeling.multipleRegressionTestBostonHousing
  */
@main def multipleRegressionTestBostonHousing(): Unit =
    analyzeDatasetMultiple("data/boston_housing.csv", -1, "Boston Housing")

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `multipleRegressionTestEnergyHeating` main function to analyze the Energy Efficiency
  * dataset for heating load using Multiple Linear Regression with all features.
  * > runMain scalation.modeling.multipleRegressionTestEnergyHeating
  */
@main def multipleRegressionTestEnergyHeating(): Unit =
    analyzeDatasetMultiple("data/energy_efficiency.csv", 8, "Energy Efficiency - Heating")

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `multipleRegressionTestEnergyCooling` main function to analyze the Energy Efficiency
  * dataset for cooling load using Multiple Linear Regression with all features.
  * > runMain scalation.modeling.multipleRegressionTestEnergyCooling
  */
@main def multipleRegressionTestEnergyCooling(): Unit =
    analyzeDatasetMultiple("data/energy_efficiency.csv", 9, "Energy Efficiency - Cooling")

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `multipleRegressionTestAllDatasets` main function to analyze all datasets
  * using Multiple Linear Regression.
  * > runMain scalation.modeling.multipleRegressionTestAllDatasets
  */
@main def multipleRegressionTestAllDatasets(): Unit =
    println("\n=== Seoul Bike Sharing Multiple Regression Analysis ===")
    multipleRegressionTestSeoulBikes()
    
    println("\n=== Auto MPG Multiple Regression Analysis ===")
    multipleRegressionTestAutoMPG()
    
    println("\n=== Boston Housing Multiple Regression Analysis ===")
    multipleRegressionTestBostonHousing()
    
    println("\n=== Energy Efficiency Heating Multiple Regression Analysis ===")
    multipleRegressionTestEnergyHeating()
    
    println("\n=== Energy Efficiency Cooling Multiple Regression Analysis ===")
    multipleRegressionTestEnergyCooling()

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** Generic function to analyze any dataset using Multiple Linear Regression with all numeric features.
  * @param filePath the path to the CSV file
  * @param targetCol the column index of the target variable (-1 means last column)
  * @param datasetName name of the dataset for display purposes
  */
def analyzeDatasetMultiple(filePath: String, targetCol: Int, datasetName: String): Unit =

    // Read and preprocess CSV file for multiple regression, ensuring only numeric columns are included
    def readAndPreprocessCSVMultiple(filePath: String, targetCol: Int): (MatrixD, VectorD, Array[String]) = {
        val source = scala.io.Source.fromFile(filePath)
        val lines = source.getLines().toList // Keep header row
        source.close()
        
        // Extract header for feature names
        val header = lines.head.split(',').map(_.trim)
        val dataLines = lines.drop(1) // Drop header row for data processing
        
        // Helper function to convert string to double, handling boolean and special cases
        def safeToDouble(s: String): Option[Double] = {
            val cleaned = s.trim.toLowerCase
            cleaned match
                case "true" => Some(1.0)
                case "false" => Some(0.0)
                case "?" | "" => None
                case _ => 
                    try Some(cleaned.toDouble)
                    catch case _: NumberFormatException => 
                        println(s"safe_toDouble: can't parse '$cleaned' to create a Double")
                        None
        }
        
        // Determine which columns contain only numeric data
        val numColumns = header.length
        val actualTargetCol = if targetCol == -1 then numColumns - 1 else targetCol // Use last column if targetCol is -1
        
        val numericColumns = (0 until numColumns).filter { col => // Include all columns
            col == actualTargetCol || // Always include target column
            dataLines.forall { line =>
                val values = line.split(',').map(_.trim)
                if values.length > col then safeToDouble(values(col)).isDefined else false
            }
        }.toVector
        
        println(s"Detected numeric columns: $numericColumns")
        
        // Filter feature names to match numeric columns
        val numericFeatureNames = numericColumns.filter(_ != actualTargetCol).map(header(_)).toArray
        
        // Filter and convert data using only numeric columns
        val cleanedData = dataLines.flatMap { line =>
            val values = line.split(',').map(_.trim)
            
            // Extract only numeric column values
            val numericValues = numericColumns.map { col =>
                if values.length > col then safeToDouble(values(col)) else None
            }
            
            // Only keep rows where all required values can be converted to numbers
            if numericValues.forall(_.isDefined) then
                Some(numericValues.map(_.get).toArray)
            else
                None
        }

        if cleanedData.isEmpty then
            throw new RuntimeException(s"No valid data found in $filePath. Check data format.")
        
        val numInstances = cleanedData.length
        val numFeatureCols = numericColumns.length - 1 // Exclude target column
        
        // Create feature matrix (exclude target column, add intercept column)
        val targetColInNumeric = numericColumns.indexOf(actualTargetCol)
        if targetColInNumeric == -1 then
            throw new RuntimeException(s"Target column $actualTargetCol is not numeric")
        
        val featureCols = numericColumns.filter(_ != actualTargetCol)
        
        val xMatrix = new MatrixD(numInstances, numFeatureCols + 1) // +1 for intercept
        val yVector = new VectorD(numInstances)

        for i <- 0 until numInstances do
            xMatrix(i, 0) = 1.0 // Intercept column
            for j <- featureCols.indices do
                xMatrix(i, j + 1) = cleanedData(i)(numericColumns.indexOf(featureCols(j)))
            yVector(i) = cleanedData(i)(targetColInNumeric)
        
        (xMatrix, yVector, numericFeatureNames)
    }

    // Manual data splitting function with a fixed random seed
    def splitData(x_data: MatrixD, y_data: VectorD, trainRatio: Double, seed: Int): (MatrixD, VectorD, MatrixD, VectorD) = {
        Random.setSeed(seed)
        val numInstances = x_data.dim
        val numFeatures = x_data.dim2
        val indices = Random.shuffle((0 until numInstances).toList)
        val splitIndex = (numInstances * trainRatio).toInt
        
        val trainIndices = indices.slice(0, splitIndex)
        val testIndices = indices.slice(splitIndex, numInstances)
        
        val x_train = new MatrixD(trainIndices.size, numFeatures)
        val y_train = new VectorD(trainIndices.size)
        val x_test = new MatrixD(testIndices.size, numFeatures)
        val y_test = new VectorD(testIndices.size)
        
        for i <- trainIndices.indices do
            val originalIndex = trainIndices(i)
            x_train(i) = x_data(originalIndex)
            y_train(i) = y_data(originalIndex)
        
        for i <- testIndices.indices do
            val originalIndex = testIndices(i)
            x_test(i) = x_data(originalIndex)
            y_test(i) = y_data(originalIndex)
        
        (x_train, y_train, x_test, y_test)
    }

    try {
        println(s"\nAnalyzing $datasetName dataset using Multiple Linear Regression...")
        
        val (x_data, y_data, numericFeatureNames) = readAndPreprocessCSVMultiple(filePath, targetCol)
        println(s"Dataset loaded: ${x_data.dim} instances, ${x_data.dim2 - 1} features") // -1 for intercept

        val (x_train, y_train, x_test, y_test) = splitData(x_data, y_data, 0.8, 42)

        // Create feature names with intercept
        val allFeatureNames = Array("intercept") ++ numericFeatureNames
        
        val mod = new Regression(x_train, y_train, allFeatureNames)
        mod.train()

        val (_, qof_train) = mod.test(x_train, y_train)
        val (_, qof_test) = mod.test(x_test, y_test)

        println("Training Performance:")
        println(s"Train RMSE: ${qof_train(6)}")
        println(s"Train R-squared: ${qof_train(0)}")
        println(s"Training Performance: {'Mean Squared Error': '${f"${qof_train(5)}%.5f"}', 'R-Squared': '${f"${qof_train(0)}%.5f"}', 'Root Mean Squared Error': '${f"${qof_train(6)}%.5f"}'}")
        
        println("\nTesting Performance:")
        println(s"Test RMSE: ${qof_test(6)}")
        println(s"Test R-squared: ${qof_test(0)}")
        println(s"Testing Performance: {'Mean Squared Error': '${f"${qof_test(5)}%.5f"}', 'R-Squared': '${f"${qof_test(0)}%.5f"}', 'Root Mean Squared Error': '${f"${qof_test(6)}%.5f"}'}")

        // Cross-validation
        val qof_cv = mod.crossValidate()
        
        // Extract numeric values from the Statistic objects
        val cv_mse = qof_cv(5).mean  // MSE mean from cross-validation
        val cv_rsq = qof_cv(0).mean  // R-squared mean from cross-validation  
        val cv_rmse = qof_cv(6).mean // RMSE mean from cross-validation
        
        println(s"Cross-Validation Results: {'MSE': '${f"$cv_mse%.5f"}', 'R²': '${f"$cv_rsq%.5f"}', 'RMSE': '${f"$cv_rmse%.5f"}'}")
        
        // Print model summary with coefficients
        println("\nModel Coefficients:")
        println(mod.summary())
        
    } catch {
        case _: java.io.FileNotFoundException =>
            println(s"Error: File not found - $filePath")
            println("Please ensure the CSV file exists in the data directory.")
        case e: Exception =>
            println(s"Error processing $datasetName dataset: ${e.getMessage}")
            e.printStackTrace()
    }

```


#### Short summary: 

empty definition using pc, found symbol in pc: 